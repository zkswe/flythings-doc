#pragma once
#include "uart/ProtocolSender.h"
#include "system/Thread.h"
#include "os/UpgradeMonitor.h"

#include "http/http_client.h"


class DownloadThread : public Thread {
protected:
    virtual bool threadLoop(){
        http::HttpClient http;
        mTextview1Ptr->setText("下载升级文件");
        //这里修改为真实服务IP
        system("mkdir /mnt/extsd/temp");
        string err = http.Download("192.168.1.1/update.img", 80, "/mnt/extsd/temp/update.img");
        mTextview1Ptr->setText(err);
        if (err.empty()) {
            UpgradeMonitor::getInstance()->checkUpgradeFile("/mnt/extsd/temp");
        }
        mButton1Ptr->setInvalid(false);
        return false;
    };

};

DownloadThread downloadThread;

/**
 * 注册定时器
 * 填充数组用于注册定时器
 * 注意：id不能重复
 */
static S_ACTIVITY_TIMEER REGISTER_ACTIVITY_TIMER_TAB[] = {
	//{0,  6000}, //定时器id=0, 时间间隔6秒
	//{1,  1000},
};

/**
 * 当界面构造时触发
 */
static void onUI_init(){
    //Tips :添加 UI初始化的显示代码到这里,如:mText1Ptr->setText("123");

}

/**
 * 当切换到该界面时触发
 */
static void onUI_intent(const Intent *intentPtr) {
    if (intentPtr != NULL) {
        //TODO
    }
}

/*
 * 当界面显示时触发
 */
static void onUI_show() {

}

/*
 * 当界面隐藏时触发
 */
static void onUI_hide() {

}

/*
 * 当界面完全退出时触发
 */
static void onUI_quit() {

}

/**
 * 串口数据回调接口
 */
static void onProtocolDataUpdate(const SProtocolData &data) {

}

/**
 * 定时器触发函数
 * 不建议在此函数中写耗时操作，否则将影响UI刷新
 * 参数： id
 *         当前所触发定时器的id，与注册时的id相同
 * 返回值: true
 *             继续运行当前定时器
 *         false
 *             停止运行当前定时器
 */
static bool onUI_Timer(int id){
	switch (id) {

		default:
			break;
	}
    return true;
}

/**
 * 有新的触摸事件时触发
 * 参数：ev
 *         新的触摸事件
 * 返回值：true
 *            表示该触摸事件在此被拦截，系统不再将此触摸事件传递到控件上
 *         false
 *            触摸事件将继续传递到控件上
 */
static bool onmainActivityTouchEvent(const MotionEvent &ev) {

	return false;
}
static bool onButtonClick_Button1(ZKButton *pButton) {
    pButton->setInvalid(true);
    downloadThread.run("download-update");
    return false;
}
