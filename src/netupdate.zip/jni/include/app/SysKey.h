/*
 * SysKey.h
 *
 *  Created on: Aug 30, 2017
 *      Author: guoxs
 */

#ifndef _APP_SYS_KEY_H_
#define _APP_SYS_KEY_H_

#define ID_SYS_KEY				100
#define ID_SYS_KEY_BACK			(ID_SYS_KEY)
#define ID_SYS_KEY_HOME			(ID_SYS_KEY + 1)

#endif /* _APP_SYS_KEY_H_ */
